#' @title WES LRR plot


plot_lrr_maf_wes <- function(proband, family, chr, cnv.start, cnv.end, region = 5,
                             window = 100, step = 50) {
    
    require(dplyr)
    require(magrittr)
    require(data.table)
    require(ggplot2)
    require(RcppRoll)
    require(stats)
    
    
    # data lrr
    {
    cnr.prob <- fread(paste0("~/ITANscratch/WES_CNV/misc/cnr/TRE_", proband,".cram.cnr")) %>% 
                        select(chromosome, start, end, log2, weight)
    
    cns.prob <- fread(paste0("~/ITANscratch/WES_CNV/misc/cns/TRE_", proband,".cram.cns")) %>% 
                        select(chromosome, start, end, log2, weight)
    
    cnr.sibl <- fread(paste0("~/ITANscratch/WES_CNV/misc/cnr/TRE_", family[1],".cram.cnr")) %>% 
        select(chromosome, start, end, log2, weight)
    
    cns.sibl <- fread(paste0("~/ITANscratch/WES_CNV/misc/cns/TRE_", family[1],".cram.cns")) %>% 
        select(chromosome, start, end, log2, weight)
    
    cnr.moth <- fread(paste0("~/ITANscratch/WES_CNV/misc/cnr/TRE_", family[2],".cram.cnr")) %>% 
        select(chromosome, start, end, log2, weight)
    
    cns.moth <- fread(paste0("~/ITANscratch/WES_CNV/misc/cns/TRE_", family[2],".cram.cns")) %>% 
        select(chromosome, start, end, log2, weight)
    
    cnr.fath <- fread(paste0("~/ITANscratch/WES_CNV/misc/cnr/TRE_", family[3],".cram.cnr")) %>% 
        select(chromosome, start, end, log2, weight)
    
    cns.fath <- fread(paste0("~/ITANscratch/WES_CNV/misc/cns/TRE_", family[3],".cram.cns")) %>% 
        select(chromosome, start, end, log2, weight)
    }
    
    # plot LRR 
    plop <- function(cns, cnr){
        
        # Region to be plotted LRR
        
        # points
        dat <- cnr %>%  filter(chromosome == chr) %>%
            filter( start >= cnv.start-region*1000000 &
                        end <= cnv.end + (region+1)*1000000 ) %>%
            filter(log2> -2 & log2 < 2) %>%
            mutate(center = (start+end)/2)
        
        # sliding window mean
        pos <- dat$center[seq(1, nrow(dat), by=step)]
        pos2 <- dat$center[seq(1, nrow(dat), by=(step/5))]
        x <- dat$log2
        val <- roll_mean(x, n = window, by = step)

        appr <- approx(x = pos[1:(length(pos)-2)], y = val, method = "constant", xout = pos2)
        appr <- data.frame(appr$x, appr$y)
        
        #region to be plotted
        appr %<>% filter(appr.x >= (cnv.start - (region)*1000000) &
                             appr.x <= (cnv.end + (region)*1000000))
        dat %<>% filter(start >= cnv.start-region*1000000 & end <= cnv.end+region*1000000)
        
        # segments
        cns %<>% filter(chromosome == chr & (   
                        (start >= cnv.start-region*1000000 & start <= cnv.end+region*1000000) |
                        (end >= cnv.start-region*1000000 & end <= cnv.end+region*1000000)     |
                        (start < cnv.start-region*1000000 & end > cnv.end+region*1000000) ) ) %>%
            arrange(start)
        
        # modifico coordinate di primo e ultimo segmento di modo che matchi con 
        # primo e ultimo bin
        if (cns$end[nrow(cns)] > dat$center[nrow(dat)]) cns$end[nrow(cns)] <- dat$center[nrow(dat)]
        if (cns$start[1] < dat$center[1]) cns$start[1] <- dat$center[1]
        
        segment_data = data.frame(x = cns$start, xend = cns$end, y = cns$log2)
        
        # Plot LRR 
        pl <- ggplot(dat, aes(x = center/1000000, y = log2)) +
            # geom_point(aes(size = weight), colour = "#FF9999") +
            geom_point(size = 1, colour = "#FF9999") +
            geom_segment(data = segment_data, aes(x = x/1000000, y = y, xend = xend/1000000, yend = y), 
                         colour = "red", size = 0.8) +
            geom_line(data = appr, aes(x = appr.x/1000000, y = appr.y), colour = "#333333", size = 0.4) + 
            xlab("Position (Mbp)") +
            ylab("log2") + 
            theme_bw() + theme(panel.border=element_blank()) +
            scale_x_continuous(labels = scales::comma)
        return(pl)
    }
    
    pl1 <- plop(cns.prob, cnr.prob)
    pl2 <- plop(cns.sibl, cnr.sibl)
    pl3 <- plop(cns.moth, cnr.moth)
    pl4 <- plop(cns.fath, cnr.fath)
    
    # MAF
    {
    # # data maf 
    # {
    #     maf.prob <- fread(paste0("~/ITANscratch/WES_CNV/BAF/", chr, "_TRE_", proband,"_BAF.csv")) %>% 
    #         select(chromosome, start, end, BAF, weight)
    #     
    #     maf.sibl <- fread(paste0("~/ITANscratch/WES_CNV/BAF/", chr, "_TRE_", family[1],"_BAF.csv")) %>% 
    #         select(chromosome, start, end, BAF, weight)
    #     
    #     maf.moth <- fread(paste0("~/ITANscratch/WES_CNV/BAF/", chr, "_TRE_", family[2],"_BAF.csv")) %>% 
    #         select(chromosome, start, end, BAF, weight)
    #     
    #     maf.fath <- fread(paste0("~/ITANscratch/WES_CNV/BAF/", chr, "_TRE_", family[3],"_BAF.csv")) %>% 
    #         select(chromosome, start, end, BAF, weight)
    # }
    # 
    # # plot MAF
    # plip <- function(maf){
    #     
    #     # Region to be plotted
    #     maf %<>%  filter(chromosome == chr) %>%
    #                 filter( start >= cnv.start-region*1000000 &
    #                         end <= cnv.end + (region+1)*1000000 ) %>%
    #                 mutate(center = (start+end)/2)
    #     
    #     pl <- ggplot(maf, aes(x = center/1000000, y = BAF)) +
    #             geom_point(size = 1, colour = "#33CCCC") +
    #             # geom_segment(aes(x = cnv.start/1000000, xend = cnv.end/1000000, y = 0.5, yend = 0.5),
    #             #              size = 0.8, colour = "#33CCFF") + # e' nelle coordinate sbagliate
    #             xlab("Position (Mbp)") +
    #             ylab("BAF") +
    #             theme_bw() +
    #             theme(panel.border=element_blank()) +
    #             scale_x_continuous(labels = scales::comma)
    # 
    # }
    # 
    # pt1 <- plip(maf.prob)
    # pt2 <- plip(maf.sibl)
    # pt3 <- plip(maf.moth)
    # pt4 <- plip(maf.fath)
    # 
    # # combine
    # plA <- cowplot::plot_grid(pl1, pt1, nrow = 2, rel_heights=c(2,1))
    # plB <- cowplot::plot_grid(pl2, pt2, nrow = 2, rel_heights=c(2,1))
    # plC <- cowplot::plot_grid(pl3, pt3, nrow = 2, rel_heights=c(2,1))
    # plD <- cowplot::plot_grid(pl4, pt4, nrow = 2, rel_heights=c(2,1))
    # 
    # # pl <- cowplot::plot_grid(plA, plB, plC, plD, nrow = 2, labels = c("A","B","C","D"))
    }
    
    pl <- cowplot::plot_grid(pl1, pl2, pl3, pl4, nrow = 2, labels = c("A","B","C","D"))
     
    pl
    
}
